Compile .java files and run the main method in the Mancala class.
It will prompt you and ask if you want to be player 1 or player 2, input that and the game starts. When it is your move, choose a position on the board to move. The positions are shown as:

11 10  9  8  7  6
 0  1  2  3  4  5

so if you are player 1, you choose positions from 0-5 and if you are player 2, you choose positions from 6-11.